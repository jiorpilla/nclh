<?php

$choices1 = [
    'Are you aware of any medical problems,disease, illness?',
    'Frequent Ear Infections?',
    'Gynecological problems',
    'Conjunctivitis / Glaucoma',
    'Do you wear glasses/contact lenses?',
    'Eye injury and / or Eye Problems?',
    'Suffered COVID-19?',
    'Tested Positive for COVID-19?',
    'Frequent Nose bleeds? Colds? Sinus Trouble?',
    'Arthritis and / or numbness',
    'Swollen Lymph Nodes',
    'Asthma and / or Wheezing?',
    'Bronchitis or Tuberculosis?',
    'Blood in urine',
    'Pneumonia?',
    'Coughing up Blood?',
    'Shortness of Breath',
    'Rheumatic Fever',
    'High / Low Blood Pressure?'
];

// print_r($choices1);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="/css/styles.min.css" rel="stylesheet">
</head>

<body class="d-flex justify-content-center align-items-center">

    <div class="container">
        <div class="content row gr-5 my-4">

            <?php include('includes/left-content.php');?>

            <div class="col-md-7">
                <div class="form-wrapper p-4">
                    <form method="POST" action="/2.php">
                        <div class="form-section row">
                            <h2 class="section-heading">Personal Medical History</h2>
                            <ol class="ps-4">
                                <li class="mb-3">
                                    <div class="question mb-3">
                                        Are you aware of any medical problems,disease, illness?
                                    </div>
                                    <div class="answer">
                                        <textarea class="form-control" ></textarea>
                                       
                                    </div>
                                </li>
                                <li>
                                    <div class="question mb-3">
                                        Do you have or have you ever been treated for the following conditions?
                                    </div>
                                    <div class="answer">
                                        <div class="form-check-wrapper row">
                                            <?php foreach($choices1 as $key => $choice) :?>
                                            <div class="form-check col-md-6 mb-2">
                                                <input class="form-check-input" type="checkbox" id="choice<?php echo $key;?>" value="<?php echo $choice;?>">
                                                <label class="form-check-label" for="choice<?php echo $key;?>">
                                                    <?php echo $choice;?>
                                                </label>
                                            </div>
                                            <?php endforeach; ?>
                                        
                                        
                                    </div>
                                    </div>
                                </li>
                            </ol>
                            <div class="mb-3 ">


                            </div>





                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">

                                <button class="btn btn-secondary me-md-1" type="button">Back</button>
                                <button type="submit" class="btn btn-primary" type="button">Next</button>
                            </div>

                    </form>
                </div>

            </div>




        </div>
    </div>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
</body>

</html>